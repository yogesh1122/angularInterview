import { Component } from "@angular/core";
@Component({
    selector:'shell',
    template:'<router-outlet></router-outlet>'
})
export class ShellComponent{
    public constructor(){}
}