import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
@Component({
    selector:'home-component',
    templateUrl:'./homepage.html',
    styleUrls:['./homepage.css']
})
export class HomepageComponent{
    public inputController : FormControl;
    public arrayNo:Array<number> = new Array<number>();
    public constructor(){
        this.inputController = new FormControl();
    }
    public getRangeNo():void{
       this.arrayNo = [];
        let num = this.inputController.value;
        let splitData = num.split("-");
        if(Array.isArray(splitData)){
            let num1 =Number(splitData[0]);
            let num2 =Number(splitData[1]);  
            for(let start = num1;start<=num2;start++){
                if(this.getPrime(start)){
                    this.arrayNo.push(start);
                }
            }
        }
    }
    public getPrime(num):boolean{
        num = Number(num);
        for(let i = 2;i<=num-1;i++){
            if(num%i==0){
                return false;
            }
        }
        return true;
    }
}