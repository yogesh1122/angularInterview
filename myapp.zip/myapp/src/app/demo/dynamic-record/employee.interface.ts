export interface Employee{
    name:string;
    gender:string;
    degree:string;
    photo:string;
    city:string;
}