import { Component, AfterViewInit } from "@angular/core";
import { FormControl } from '@angular/forms';
import { Employee } from './employee.interface';
@Component({
    selector:'dynamic-record',
    templateUrl:'./record.html',
    styleUrls:['./record.css']
})
export class DynamicComponent implements AfterViewInit{
    public photo:HTMLImageElement;
    ngAfterViewInit(){
        this.photo = <HTMLImageElement> document.querySelector(".image");
    }
    public nameControl:FormControl;
    public genderControl:FormControl;
    public cityControl:FormControl;
    public allEmployees:Array<Employee> = new Array<Employee>();
    
    public tableHeader = [
        'Name',
        'Gender',
        'City',
        'Degree',
        'Photo'
    ];
    public cities = [
        'Pune',
        'Mumbai',
        'Nashik',
        'Aurangabad',
        'Kalyan',
        'Bakwas Amravati'
    ];
    public degries=[
        {
            name:'MBA',
            selected:false
        },
        {
            name:'BA-3',
            selected:false
        },
        {
            name:'M-Tech',
            selected:false
        },
        {
            name:'B-Tech',
            selected:false
        },
        {
            name:'BE(CSE)',
            selected:false
        },
        {
            name:'MCA',
            selected:false
        },
    ];
    public constructor(){
        this.cityControl= new FormControl();
        this.genderControl = new FormControl();
        this.nameControl = new FormControl();
    }

    public displayImage(ev:Event):void{
        let inputFile:HTMLInputElement = <HTMLInputElement> ev.target;
        if('files' in inputFile){
            let file = inputFile.files[0];
            this.readFile(file);

        }
    }
    public imageData:string='';
    private readFile(file:File):void{
        let reader = new FileReader();
        reader.onload = (ev)=>{
            this.imageData = <string>reader.result;
        };
        reader.readAsDataURL(file);
    }
    public saveData():void{
        let emp = <Employee>{};
        emp.name = this.nameControl.value;
        emp.city = this.cityControl.value;
        emp.gender = this.genderControl.value;
        emp.photo = this.imageData;
        emp.degree = this.getSelectedElement(this.degries);
        this.allEmployees.push(emp);
    }
    public changeDegree(ev,degree:any) {
        let checkBox = <HTMLInputElement>ev.target;
        degree.selected = checkBox.checked;
        console.log(degree);
    }
    public getSelectedElement(degries:Array<any>):string{
        let degreestring='';
        for(let degree of degries){
            if(degree.selected){
                degreestring+=degree.name+" ";
            }
        }
        return degreestring;
    }
}