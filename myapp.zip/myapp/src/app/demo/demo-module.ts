import { NgModule } from "@angular/core";
import { HomepageComponent } from './hemo-page/homepage.component';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { DynamicComponent } from './dynamic-record/record';
import { Routes, RouterModule } from '@angular/router';
import { ShellComponent } from './shell-component';
const route:Routes = [
    {
        path:'dynamic-record',
        component:DynamicComponent
    },
    {
        path:'all-prime',
        component:HomepageComponent
    },
    {
        path:'',
        redirectTo:'/all-prime',
        pathMatch:'full'
    },
    {
        path:'**',
        redirectTo:'/all-prime',
        pathMatch:'full'

    }
];


@NgModule({
    declarations:[
            HomepageComponent, 
            ShellComponent, 
            DynamicComponent],
    exports:[
        
    ],
    entryComponents:[],
    providers:[],
    bootstrap:[ShellComponent],
    imports:[BrowserModule, ReactiveFormsModule , RouterModule.forRoot(route)]
})
export class DemoModule{
    public constructor(){}
}